package com.example.checklogin.data;

import com.example.checklogin.data.model.LoggedInUser;

/**
 * Class that requests authentication and user information from the remote data source and
 * maintains an in-memory cache of login status and user credentials information.
 */
public class WelcomeRepository {

    private static volatile WelcomeRepository instance;

    private WelcomeDataSource dataSource;

    // If user credentials will be cached in local storage, it is recommended it be encrypted
    // @see https://developer.android.com/training/articles/keystore
    private LoggedInUser user = null;

    // private constructor : singleton access
    private WelcomeRepository(WelcomeDataSource dataSource) {
        this.dataSource = dataSource;
    }

    public static WelcomeRepository getInstance(WelcomeDataSource dataSource) {
        if (instance == null) {
            instance = new WelcomeRepository(dataSource);
        }
        return instance;
    }



    public Result<LoggedInUser> displayWelcome() {
        // handle login
        Result result = dataSource.displayWelcome();
//        if (result instanceof Result.Success) {
//            setLoggedInUser(((Result.Success<LoggedInUser>) result).getData());
//        }
        return result;
    }




}