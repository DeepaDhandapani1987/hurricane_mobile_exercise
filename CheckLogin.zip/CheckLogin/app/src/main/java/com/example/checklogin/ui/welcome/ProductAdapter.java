package com.example.checklogin.ui.welcome;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.checklogin.R;

import java.util.ArrayList;

public class ProductAdapter extends ArrayAdapter {

    ArrayList<Product> productArrayList;
    String productName;
    Context mContext;

    public ProductAdapter(@NonNull Context context, ArrayList<Product> listOfValues) {
        super(context,0,listOfValues );
        mContext = context;
        productArrayList = listOfValues;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = convertView;

        if(view == null){
            view = LayoutInflater.from(getContext()).inflate(R.layout.simple_layout,parent,false);

        }

        TextView productTxt = view.findViewById(R.id.text_product_name);

        if(productArrayList !=null && productArrayList.size() > 0){
            Product product = productArrayList.get(position);
            productName = product.productName;
            productTxt.setText(product.productName);
        }

//        view.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(mContext,productName,Toast.LENGTH_LONG).show();
//            }
//        });


        return view;
    }
}
