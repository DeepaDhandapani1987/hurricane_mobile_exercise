package com.example.checklogin.data;

import com.example.checklogin.data.model.LoggedInUser;

import java.io.IOException;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class WelcomeDataSource {

    public Result displayWelcome() {

        try {
            // TODO: handle loggedInUser authentication
            LoggedInUser fakeUser =
                    new LoggedInUser(
                            java.util.UUID.randomUUID().toString(),
                            "Welcome");
            return new Result.DisplayMessage();
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }


}