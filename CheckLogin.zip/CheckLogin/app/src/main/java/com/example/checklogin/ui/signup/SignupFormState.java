package com.example.checklogin.ui.signup;

import androidx.annotation.Nullable;

public class SignupFormState {

    @Nullable
    private Integer usernameError;

    @Nullable
    private Integer emailError;

    @Nullable
    private Integer passwordError;

    @Nullable
    private Integer confirmpasswordError;

    private boolean isDataValid;

    SignupFormState(@Nullable Integer usernameError,
                    @Nullable Integer emailError,
                    @Nullable Integer passwordError,
                    @Nullable Integer confirmpasswordError){
        this.usernameError = usernameError;
        this.emailError = emailError;
        this.passwordError = passwordError;
        this.confirmpasswordError = confirmpasswordError;
        this.isDataValid = false;
    }

    SignupFormState(boolean isDataValid){
        this.usernameError = null;
        this.emailError = null;
        this.passwordError = null;
        this.confirmpasswordError = null;
        this.isDataValid = isDataValid;

    }

    @Nullable
    public Integer getUsernameError() {
        return usernameError;
    }

    @Nullable
    public Integer getEmailError() {
        return emailError;
    }

    @Nullable
    public Integer getPasswordError() {
        return passwordError;
    }

    @Nullable
    public Integer getConfirmpasswordError() {
        return confirmpasswordError;
    }

    public boolean isDataValid() {
        return isDataValid;
    }
}
