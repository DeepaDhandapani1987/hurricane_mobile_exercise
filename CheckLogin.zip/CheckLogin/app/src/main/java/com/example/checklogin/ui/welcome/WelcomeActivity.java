package com.example.checklogin.ui.welcome;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.checklogin.databinding.ActivityLoginBinding;
import com.example.checklogin.databinding.ActivityWelcomeBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class WelcomeActivity extends AppCompatActivity {

    private WelcomeViewModel welcomeViewModel;
    private ActivityWelcomeBinding dataBinding;
    ProgressDialog progressDialog;
    ArrayList<Product> al;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        dataBinding = ActivityWelcomeBinding.inflate(getLayoutInflater());
        setContentView(dataBinding.getRoot());

        welcomeViewModel = new ViewModelProvider(this, new WelcomeViewModelFactory())
                .get(WelcomeViewModel.class);

        final TextView welcomeTextView = dataBinding.textwelcome;
        final ListView listOfData = dataBinding.displayValues;

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

String url = "https://av.sc.com/sg/rtob/categories.json";

        StringRequest request = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String string) {
                parseJsonData(string,listOfData);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(getApplicationContext(), "Some error occurred!!", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });

        RequestQueue rQueue = Volley.newRequestQueue(WelcomeActivity.this);
        rQueue.add(request);

    }



    void parseJsonData(String jsonString, ListView listOfData) {
        try {
            JSONObject object = new JSONObject(jsonString);
            JSONArray categoriesArray = object.getJSONArray("categories");


            al = new ArrayList<Product>();

            for(int i = 0; i < categoriesArray.length(); ++i) {


                JSONObject categoryObject = categoriesArray.getJSONObject(i);

                JSONArray productArray = categoryObject.getJSONArray("products");



                for(int j = 0; j < productArray.length(); ++j) {
                    JSONObject productObject = productArray.getJSONObject(j);
                    String productName = productObject.getString("product-name");
                    String productDetails = productObject.getString("product-details");


                    Product product = new Product();
                    product.productName = productName;
                    product.productDetails = productDetails;
                    al.add(product);

                }

            }

            ArrayAdapter adapter = new ProductAdapter(this, al);
            listOfData.setAdapter(adapter);

            listOfData.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                    String name = al.get(position).productName;
                    String url = al.get(position).productDetails;
                    Toast.makeText(WelcomeActivity.this,name +" \n "+url,Toast.LENGTH_LONG).show();

                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(browserIntent);

                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }

        progressDialog.dismiss();
    }
}
