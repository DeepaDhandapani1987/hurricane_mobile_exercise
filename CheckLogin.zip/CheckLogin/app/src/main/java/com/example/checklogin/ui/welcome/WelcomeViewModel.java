package com.example.checklogin.ui.welcome;

import androidx.lifecycle.ViewModel;

public class WelcomeViewModel extends ViewModel {
    
    
}
