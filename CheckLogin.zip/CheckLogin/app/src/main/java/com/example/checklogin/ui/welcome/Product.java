package com.example.checklogin.ui.welcome;

public class Product {

    public String productName;
    public String productDetails;


}
