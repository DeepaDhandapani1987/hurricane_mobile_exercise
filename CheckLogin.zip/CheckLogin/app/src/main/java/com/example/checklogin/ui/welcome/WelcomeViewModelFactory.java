package com.example.checklogin.ui.welcome;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.example.checklogin.data.LoginDataSource;
import com.example.checklogin.data.LoginRepository;
import com.example.checklogin.data.WelcomeDataSource;
import com.example.checklogin.data.WelcomeRepository;
import com.example.checklogin.ui.login.LoginViewModel;

public class WelcomeViewModelFactory implements ViewModelProvider.Factory{
    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> aClass) {
        if(aClass.isAssignableFrom(WelcomeViewModel.class)){
            return (T) new WelcomeViewModel();
        }else{
            throw new IllegalArgumentException("Unknown ViewModel class");
        }


    }
}
