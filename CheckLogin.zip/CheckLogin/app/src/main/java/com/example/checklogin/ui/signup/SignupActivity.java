package com.example.checklogin.ui.signup;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.checklogin.databinding.ActivitySignupBinding;

import com.google.android.material.textfield.TextInputEditText;

public class SignupActivity extends AppCompatActivity {

    private SignupViewModel signupViewModel;
    private ActivitySignupBinding signupBinding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        signupBinding = ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(signupBinding.getRoot());

        signupViewModel = new ViewModelProvider(this, new SignupViewModelFactory())
                .get(SignupViewModel.class);

        final Button signupButton = signupBinding.login;
        final TextInputEditText userNameInputEditText = signupBinding.textInputEditUsername;
        final TextInputEditText emailInputEditText = signupBinding.textInputEditEmail;
        final TextInputEditText passwordInputEditText = signupBinding.textInputEditUsername;
        final TextInputEditText confirmPasswordInputEditText = signupBinding.textInputEditEmail;

        signupViewModel.getSignupFormState().observe(this, new Observer<SignupFormState>() {
            @Override
            public void onChanged(@Nullable SignupFormState signupFormState) {
                if (signupFormState == null) {
                    return;
                }
                signupButton.setEnabled(signupFormState.isDataValid());
                if (signupFormState.getUsernameError() != null) {
                    userNameInputEditText.setError(getString(signupFormState.getUsernameError()));
                }
                if (signupFormState.getEmailError() != null) {
                    emailInputEditText.setError(getString(signupFormState.getEmailError()));
                }
                if (signupFormState.getPasswordError() != null) {
                    passwordInputEditText.setError(getString(signupFormState.getPasswordError()));
                }
                if (signupFormState.getConfirmpasswordError() != null) {
                    confirmPasswordInputEditText.setError(getString(signupFormState.getConfirmpasswordError()));
                }
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                signupViewModel.loginDataChanged(userNameInputEditText.getText().toString(),
                        emailInputEditText.getText().toString(),
                        passwordInputEditText.getText().toString(),
                        confirmPasswordInputEditText.getText().toString());
            }
        };
        userNameInputEditText.addTextChangedListener(afterTextChangedListener);
        emailInputEditText.addTextChangedListener(afterTextChangedListener);
        passwordInputEditText.addTextChangedListener(afterTextChangedListener);
        confirmPasswordInputEditText.addTextChangedListener(afterTextChangedListener);

    }
}
