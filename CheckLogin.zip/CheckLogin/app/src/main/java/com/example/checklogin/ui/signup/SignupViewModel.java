package com.example.checklogin.ui.signup;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.checklogin.R;
import com.example.checklogin.data.Result;
import com.example.checklogin.data.SignupRepository;
import com.example.checklogin.data.model.LoggedInUser;


public class SignupViewModel extends ViewModel {

    private MutableLiveData<SignupFormState> signupFormState = new MutableLiveData<>();
    private MutableLiveData<SignUpResult> signUpResult = new MutableLiveData<>();
    private SignupRepository signupRepository;

    SignupViewModel(SignupRepository signupRepository){
        this.signupRepository = signupRepository;
    }

    LiveData<SignupFormState> getSignupFormState(){
        return signupFormState;
    }

    public void login(String username, String email,
                      String password, String confirmPassword) {
        // can be launched in a separate asynchronous job
        Result<LoggedInUser> result = signupRepository.login(username,email,password,confirmPassword);

        if (result instanceof Result.Success) {
            LoggedInUser data = ((Result.Success<LoggedInUser>) result).getData();
            signUpResult.setValue(new SignUpResult(new SignUpUserView(data.getDisplayName())));
        } else {
            signUpResult.setValue(new SignUpResult(R.string.login_failed));
        }
    }
    public void signup(String username, String email,
                       String password, String confirmPassword) {
        // can be launched in a separate asynchronous job
        Result<LoggedInUser> result = signupRepository.login(username,email,password,confirmPassword);

        if (result instanceof Result.Success) {
            LoggedInUser data = ((Result.Success<LoggedInUser>) result).getData();
            signUpResult.setValue(new SignUpResult(new SignUpUserView(data.getDisplayName())));
        } else {
            signUpResult.setValue(new SignUpResult(R.string.login_failed));
        }
    }

    public void loginDataChanged(String username, String email,
                                 String password, String confirmPassword) {
        if (!isUserNameValid(username)) {
            signupFormState.setValue(new SignupFormState(R.string.invalid_username,null,null,null));
        } else if (!isEmailValid(email)) {
            signupFormState.setValue(new SignupFormState(null,R.string.invalid_email,null,null));
        }else if (!isPasswordValid(password)) {
            signupFormState.setValue(new SignupFormState(null,null,R.string.invalid_password,null));
        }else if (!isConfirmPasswordValid(confirmPassword)) {
            signupFormState.setValue(new SignupFormState(null,null,null,R.string.invalid_confirm_password));
        } else {
            signupFormState.setValue(new SignupFormState(true));
        }
    }

    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }else{
            return !username.trim().isEmpty();
        }
//        if (username.contains("@")) {
//            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
//        } else {
//            return !username.trim().isEmpty();
//        }
    }

    // A placeholder username validation check
    private boolean isEmailValid(String email) {
        if (email == null) {
            return false;
        }else{

            String emailPattern = "^([\\w-\\.]+){1,64}@([\\w&&[^_]]+){2,255}.[a-z]{2,}$";

            if (email.matches(emailPattern)) {
                return true;
            }else{
                return false;
            }

//            return !email.trim().isEmpty();
        }
//        if (username.contains("@")) {
//            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
//        } else {
//            return !username.trim().isEmpty();
//        }
    }

    // A placeholder username validation check
    private boolean isPasswordValid(String password) {
        if (password == null) {
            return false;
        }else{
            return !password.trim().isEmpty();
        }
//        if (username.contains("@")) {
//            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
//        } else {
//            return !username.trim().isEmpty();
//        }
    }

    // A placeholder username validation check
    private boolean isConfirmPasswordValid(String confirmPassword) {
        if (confirmPassword == null) {
            return false;
        }else{
            return !confirmPassword.trim().isEmpty();
        }
//        if (username.contains("@")) {
//            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
//        } else {
//            return !username.trim().isEmpty();
//        }
    }
}
